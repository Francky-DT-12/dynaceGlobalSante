// Modifiez ici vos coordonnées : elles sont utilisées partout sur le site.
export const SITE = {
  phoneIntl: "237695448819", // format international sans le "+" (pour WhatsApp)
  phoneDisplay: "+237 695 448 819",
  defaultCity: "Yaoundé",
};

export const waLink = (text: string) =>
  `https://wa.me/${SITE.phoneIntl}?text=${encodeURIComponent(text)}`;
