import CopyPhone from "../components/CopyPhone";
import OrderForm from "../components/OrderForm";
import PickLink from "../components/PickLink";
import FloatingWhatsApp from "../components/FloatingWhatsApp";
import { SITE, waLink } from "../lib/config";
import { products } from "../lib/products";

const faq = [
  {
    q: "Quels sont les tarifs des produits Dynace au Cameroun ?",
    a: "Les tarifs sont fixés en FCFA selon les gammes et les formats officiels. Vous pouvez sélectionner un produit dans le formulaire ci-dessous ou nous contacter sur WhatsApp pour obtenir le tarif précis du jour et les disponibilités en stock.",
  },
  {
    q: "Comment s'effectue le paiement ?",
    a: "Pour garantir la sécurité et la flexibilité, les paiements s'effectuent par Mobile Money (Orange Money, MTN MoMo) ou directement en espèces à la livraison pour les remises en main propre à Yaoundé.",
  },
  {
    q: "Assurez-vous la livraison dans toutes les villes du Cameroun ?",
    a: "Oui. Nous organisons des envois quotidiens sécurisés vers Douala, Bafoussam, Garoua, Bamenda, Bertoua, Kribi et l'ensemble des régions via les agences de messagerie fiables.",
  },
  {
    q: "Quelle est la nature médicale de ces compléments ?",
    a: "Les produits Dynace Global sont des compléments alimentaires botaniques et des soins de bien-être haut de gamme issus de la recherche en biothérapie végétale. Ils visent à soutenir l'équilibre et la vitalité générale, mais ne remplacent pas une prescription médicale ni l'avis d'un professionnel de santé.",
  },
  {
    q: "Quelle est la relation de ce site avec Dynace Global ?",
    a: "Ce site est édité par un partenaire et distributeur indépendant agréé de Dynace Global au Cameroun. Pour consulter le portail institutionnel international de l'entreprise, vous pouvez visiter le site officiel de Dynace Global.",
  },
];

export default function Home() {
  return (
    <div>
      {/* Barre supérieure institutionnelle */}
      <div className="topbar">
        <div className="container topbar-content">
          <div className="topbar-left">
            <span className="topbar-badge">Partenaire Agréé</span>
            <span>Distributeur Indépendant Dynace Global · {SITE.defaultCity}, Cameroun</span>
          </div>
          <div className="topbar-right">
            <span className="topbar-phone">
              <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 4V3z" />
              </svg>
              {SITE.phoneDisplay}
            </span>
          </div>
        </div>
      </div>

      {/* Header avec Logo officiel sur fond blanc */}
      <header className="site-header">
        <div className="container header-inner">
          <a className="logo-link" href="#accueil" aria-label="Dynace Cameroun Accueil">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="logo-img" src="/img/logo.webp" alt="Dynace Global" width={130} height={40} />
            <div className="logo-label">
              <span className="logo-title">Dynace Cameroun</span>
              <span className="logo-subtitle">Partenaire Indépendant</span>
            </div>
          </a>

          <nav className="main-nav" aria-label="Navigation principale">
            <a href="#produits">Gamme Produits</a>
            <a href="#biotherapie">Sciences & Qualité</a>
            <a href="#opportunite">Opportunité Réseau</a>
            <a href="#commander">Commander</a>
            <a href="#faq">Questions Fréquentes</a>
          </nav>

          <a
            className="btn btn-primary btn-sm"
            href="#commander"
          >
            Commander un produit
          </a>
        </div>
      </header>

      <main id="accueil">
        {/* Section Héro : Présentation épurée et biomédicale */}
        <section className="hero-section">
          <div className="container hero-grid">
            <div className="hero-content">
              <div className="hero-tag">
                <span>Biothérapie Cellulaire & Santé Botanique</span>
              </div>

              <h1 className="hero-title">
                L&apos;excellence des solutions <span>Dynace Global</span> au Cameroun.
              </h1>

              <p className="hero-desc">
                Des formulations avancées à base de cellules souches végétales, antioxydants puissants et nutriments botaniques. Bénéficiez d&apos;un conseil direct et d&apos;un approvisionnement sécurisé à Yaoundé et dans tout le pays.
              </p>

              <div className="hero-actions">
                <a className="btn btn-primary" href="#commander">
                  Acheter Dynace Rocenta
                </a>
                <a className="btn btn-outline" href="#produits">
                  Consulter le catalogue
                </a>
              </div>

              <div className="hero-features">
                <div className="hero-feature-item">
                  <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Produits 100% Originaux</span>
                </div>
                <div className="hero-feature-item">
                  <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Stock disponible à Yaoundé</span>
                </div>
                <div className="hero-feature-item">
                  <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Expédition toutes régions</span>
                </div>
              </div>
            </div>

            {/* Vitrine Héro avec Grande Bulle Produit Phare */}
            <div className="hero-visual-card">
              <span className="hero-badge-tag">Produit de Référence</span>
              <div className="hero-bubble">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src="/img/rocenta.webp" alt="Dynace Rocenta Boisson Botanique" />
              </div>
              <h2 className="hero-product-name">Dynace Rocenta</h2>
              <p className="hero-product-sub">Cellules souches végétales & rose bulgare</p>
            </div>
          </div>
        </section>

        {/* Section Piliers : Icônes filaires (outline) bleues */}
        <section className="section-piliers" id="biotherapie">
          <div className="container">
            <div className="piliers-grid">
              {/* Pilier 1 : Biothérapie & Sciences */}
              <div className="pilier-card">
                <div className="pilier-icon-box">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="24" height="24">
                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
                  </svg>
                </div>
                <h3>Biothérapie & Cellules Souches</h3>
                <p>Formulations innovantes exploitant les actifs botaniques et antioxydants pour soutenir le renouvellement cellulaire naturel.</p>
              </div>

              {/* Pilier 2 : Qualité Certifiée */}
              <div className="pilier-card">
                <div className="pilier-icon-box">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="24" height="24">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                </div>
                <h3>Qualité & Normes Internationales</h3>
                <p>Produits élaborés selon des protocoles stricts de contrôle qualité, garantissant pureté et conformité internationale.</p>
              </div>

              {/* Pilier 3 : Disponibilité Locale Cameroun */}
              <div className="pilier-card">
                <div className="pilier-icon-box">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="24" height="24">
                    <rect x="1" y="3" width="15" height="13" />
                    <polygon points="16 8 20 8 23 11 23 16 16 16 16 8" />
                    <circle cx="5.5" cy="18.5" r="2.5" />
                    <circle cx="18.5" cy="18.5" r="2.5" />
                  </svg>
                </div>
                <h3>Logistique & Présence au Cameroun</h3>
                <p>Stock basé à Yaoundé pour un retrait immédiat ou des expéditions sous 24h à 48h vers toutes les villes du territoire national.</p>
              </div>

              {/* Pilier 4 : Suivi et Conseil Direct */}
              <div className="pilier-card">
                <div className="pilier-icon-box">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="24" height="24">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                    <circle cx="9" cy="7" r="4" />
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                    <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                  </svg>
                </div>
                <h3>Accompagnement Personnalisé</h3>
                <p>Conseils personnalisés de votre partenaire agréé sur la posologie et le suivi de vos programmes de bien-être.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Section Produits : Grandes Bulles Épurées */}
        <section className="section-products" id="produits">
          <div className="container">
            <div className="section-head">
              <span className="section-tag">Catalogue des Produits</span>
              <h2 className="section-title">Les Formules Dynace Global</h2>
              <p className="section-desc">
                Découvrez la gamme complète de compléments nutritionnels et de boissons fonctionnelles. Cliquez sur « Commander » pour pré-remplir votre demande.
              </p>
            </div>

            <div className="products-grid">
              {products.map((p) => (
                <article className="product-card" key={p.name}>
                  <div className="product-category-row">
                    <span className="product-category">{p.category}</span>
                    <span className="product-highlight">{p.highlight}</span>
                  </div>

                  {/* Grande Bulle Produit */}
                  <div className="product-bubble-frame">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      className={p.cover ? "cover" : undefined}
                      src={`/img/${p.image}.webp`}
                      alt={p.name}
                      loading="lazy"
                    />
                  </div>

                  <div className="product-info">
                    <h3 className="product-name">{p.name}</h3>
                    <p className="product-desc">{p.description}</p>
                  </div>

                  <div className="product-footer">
                    <span className="product-price">{p.price}</span>
                    <PickLink name={p.name} />
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Section Opportunité Réseau Dynace Global */}
        <section className="section-opportunite" id="opportunite">
          <div className="container opportunite-grid">
            <div className="opportunite-content">
              <span className="opportunite-tag">Développement & Affiliation</span>
              <h2 className="opportunite-title">Rejoignez le Réseau Dynace Global au Cameroun</h2>
              <p className="opportunite-desc">
                Dynace Global propose un modèle éprouvé de vente directe et de distribution dans l&apos;industrie en pleine expansion du bien-être cellulaire. Rejoignez notre équipe de partenaires au Cameroun pour développer votre propre activité en toute autonomie.
              </p>

              <div className="opportunite-points">
                <div className="opp-point-item">
                  <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Plan de compensation compétitif (commissions directes et binaire).</span>
                </div>
                <div className="opp-point-item">
                  <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Accès aux outils marketing et supports officiels de la marque.</span>
                </div>
                <div className="opp-point-item">
                  <svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Formation et accompagnement continu par les leaders régionaux.</span>
                </div>
              </div>
            </div>

            <div className="opportunite-cta-card">
              <h3>Devenir Partenaire Dynace</h3>
              <p>Recevez la documentation officielle sur le plan de rémunération et les étapes d&apos;inscription.</p>
              <a
                className="btn btn-primary"
                href={waLink("Bonjour, je souhaite obtenir les informations pour m'inscrire comme partenaire distributeur Dynace Global.")}
                target="_blank"
                rel="noopener noreferrer"
              >
                S&apos;inscrire en ligne
              </a>
              <span style={{ fontSize: "12px", color: "var(--text-light)" }}>
                Échange professionnel confidentiel
              </span>
            </div>
          </div>
        </section>

        {/* Section Commande et Tunnel WhatsApp */}
        <section className="section-order" id="commander">
          <div className="container order-layout">
            <div className="order-intro">
              <span className="section-tag">Commande Express</span>
              <h2 className="section-title">Commander vos produits Dynace</h2>
              <p className="section-desc">
                Remplissez les informations ci-contre pour générer votre commande. Vous serez automatiquement redirigé vers WhatsApp pour la validation et l&apos;organisation de la livraison.
              </p>

              <div className="order-guarantee-list">
                <div className="guarantee-item">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                  <div>
                    <h4>Confidentialité Respectée</h4>
                    <p>Aucune information bancaire n&apos;est saisie sur ce site internet.</p>
                  </div>
                </div>

                <div className="guarantee-item">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                  <div>
                    <h4>Traitement Réactif</h4>
                    <p>Confirmation du stock et du délai d&apos;envoi en quelques minutes.</p>
                  </div>
                </div>
              </div>
            </div>

            <OrderForm />
          </div>
        </section>

        {/* Section FAQ Sobre */}
        <section className="section-faq" id="faq">
          <div className="container">
            <div className="section-head">
              <span className="section-tag">Renseignements Utiles</span>
              <h2 className="section-title">Foire Aux Questions</h2>
            </div>

            <div className="faq-list">
              {faq.map((f) => (
                <details className="faq-entry" key={f.q}>
                  <summary className="faq-question">
                    <span>{f.q}</span>
                    <svg className="faq-icon" viewBox="0 0 20 20" fill="currentColor">
                      <path
                        fillRule="evenodd"
                        d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </summary>
                  <p>{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Bandeau de Contact Direct */}
        <section className="section-contact-bar">
          <div className="container">
            <div className="contact-card-inner">
              <div className="contact-left">
                <h3>Une question sur un produit Dynace ?</h3>
                <p>Notre conseiller vous répond à Yaoundé pour vous orienter selon vos besoins.</p>
              </div>

              <div className="contact-right">
                <span className="contact-phone-display">{SITE.phoneDisplay}</span>
                <a
                  className="btn btn-wa"
                  href={waLink("Bonjour, je vous contacte depuis votre site pour des conseils sur la gamme Dynace.")}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Écrire sur WhatsApp
                </a>
                <CopyPhone />
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer Officiel Conforme */}
      <footer className="site-footer">
        <div className="container">
          <div className="footer-top">
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/img/logo.webp" alt="Dynace Global" width={110} height={34} style={{ opacity: 0.9 }} />
              <span style={{ fontWeight: 700, color: "var(--dynace-navy)" }}>Dynace Cameroun</span>
            </div>
            <span>Distribution Agréée · Yaoundé, Cameroun</span>
          </div>

          <div className="footer-disclaimers">
            <p>
              <strong>Statut de Partenaire Indépendant :</strong> Ce portail est géré par un distributeur et affilié indépendant de Dynace Global (Dynamic Ace Global). Il ne remplace pas le site officiel de l&apos;entreprise. Les marques et logos restent la propriété exclusive de Dynace Global.
            </p>
            <p>
              <strong>Avertissement Réglementaire :</strong> Les produits présentés sont des compléments alimentaires botaniques et des articles de bien-être. Ils ne sont pas destinés à diagnostiquer, traiter, guérir ou prévenir une maladie. Les résultats individuels peuvent varier.
            </p>
          </div>

          <div className="footer-bottom">
            © {new Date().getFullYear()} Dynace Cameroun Partenaire Indépendant. Tous droits réservés.
          </div>
        </div>
      </footer>

      {/* Bouton WhatsApp flottant discret */}
      <FloatingWhatsApp />
    </div>
  );
}
